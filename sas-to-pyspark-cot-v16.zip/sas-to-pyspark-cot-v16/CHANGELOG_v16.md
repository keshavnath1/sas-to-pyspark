# v16 Change Log — Differences from v15

## Summary

Version 16 fixes the GitHub Copilot Agent Mode prompt-file restriction that blocked workspace read/write access. It also adds a dedicated CSV-driven pytest and SAS tie-out capability.

---

## Modified Files

| File | What changed | Why it changed |
|---|---|---|
| `.github/skills/sas-trace-extractor/SKILL.md` | Replaced with the complete modern Agent Mode version. It explicitly prohibits legacy `@workspace`, attachment requests for in-workspace files, and manual Python extraction scripts. It requires the agent to create `stage1_extraction/output/` and write `execution_trace.json` directly. | Prevents Stage 1 from asking the user to paste files or create/run scripts. |
| `.github/prompts/run-stage1.prompt.md` | Removed the restrictive `tools: ['vscode/askQuestions']` frontmatter. Added direct instructions to use workspace tools, create the output directory, and write the JSON artifact. | The prior tool list allowed only questions and blocked file/terminal access. |
| `.github/prompts/run-review.prompt.md` | Removed the restrictive read/write tool list. Clarified the required rule-by-rule audit and Mermaid output. | Allows Agent Mode to read generated code and write the review report using its normal tool permissions. |
| `.github/prompts/run-tests.prompt.md` | Removed the restrictive read/write/run-command tool list. Added instructions to use standard Agent Mode tools and run pytest directly. | Allows Agent Mode to create tests and execute pytest. |
| `.github/copilot-instructions.md` | Added `/run-csv-tieout-tests` and conditional routing: use CSV-driven testing when `data/input_csv/` is populated; otherwise use synthetic pytest. Added handling for `TIE-OUT BLOCKED` and `TIE-OUT FAIL`. | Makes the new test and tie-out capability part of the agent orchestration flow. |
| `README.md` | Updated project version to v16. Added CSV-driven test/tie-out setup, `/run-csv-tieout-tests`, and the Agent Mode tool-frontmatter correction. | Documents the new capability and current operating model. |

---

## New Files

| File | Purpose |
|---|---|
| `.github/skills/sas-csv-tieout-test-harness/SKILL.md` | Full Stage 4c skill for local CSV profiling, deterministic scenario selection, pytest generation, optional SAS expected-output tie-out, Markdown reporting, and Mermaid diagrams. |
| `.github/prompts/run-csv-tieout-tests.prompt.md` | Copilot slash prompt: `/run-csv-tieout-tests <module_name>`. It intentionally has no `tools:` frontmatter. |
| `tests/test_data_config.yaml` | Per-module configuration for CSV locations, input/expected-output mapping, primary key, comparison columns, numeric tolerances, and sensitive columns. |
| `data/input_csv/.gitkeep` | Preserves the standard location for local input CSV files. |
| `data/tie_out/.gitkeep` | Preserves the standard location for SAS expected-output CSV files. |
| `tests/manifests/.gitkeep` | Preserves the output location for generated metadata-only data manifests. |
| `tests/fixtures/.gitkeep` | Preserves the output location for small approved/sanitized test fixtures. |
| `CHANGELOG_v16.md` | This exact v15-to-v16 change list. |

---

## New Data Layout

```text
data/
  input_csv/        # Place CSV inputs used by generated Python/NumPy modules
  tie_out/          # Place corresponding SAS expected-output CSV files

tests/
  test_data_config.yaml
  manifests/        # Metadata-only profiles and deterministic selection rules
  fixtures/         # Small approved or sanitized fixtures only
```

## New Test Command

```text
/run-csv-tieout-tests <module_name>
```

The command profiles local input CSVs without exposing raw data, generates deterministic normal/boundary/property tests, and compares selected Python/NumPy results to SAS expected outputs when `tests/test_data_config.yaml` supplies the required key and field mapping.
