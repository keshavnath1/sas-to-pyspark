# SAS-to-PySpark Migration — GitHub Copilot Agent Skills (v16)

This repository provides a structured GitHub Copilot Agent Mode workflow for converting legacy SAS programs into the **production LP Emulator NumPy inference pattern**.

> **Target architecture:** preserve SAS business formulas, variable names, coefficients, and outputs while replacing population-level intermediate processing with loan-level composed execution and controlled final output.

The original project name refers to SAS-to-PySpark migration. The current production target is more specific: **SAS → the existing LP Emulator NumPy/ComposedModule implementation pattern**, not generic DataFrame code.

---

## What You Do First — Required One-Time Setup

Before translating a SAS program, seed the code-generation skill with the coding patterns from your production LP Emulator repository. This prevents Copilot from using generic Python patterns instead of your team's actual production conventions.

| Order | Action in GitHub Copilot Agent Mode | Save the output here |
|---:|---|---|
| 1 | Run **Prompt 1** from `pasted_content_12.txt` against the production codebase to analyze the author's architecture and coding patterns. | `.github/skills/sas-code-generator/references/author_patterns.md` |
| 2 | Run **Prompt 3** from `pasted_content_12.txt` to identify the performance-improvement pattern. | `.github/skills/sas-code-generator/references/performance_improvement_analysis.md` |
| 3 | Run **Prompt 2** from `pasted_content_12.txt` to derive explicit generation rules and an author-style checklist. | `.github/skills/sas-code-generator/references/copilot_generation_rules.md` |
| 4 | Replace the four starter templates with approved extracts from production code. | See the template table below. |

### Production Templates to Copy

| Template in this repository | Production pattern to copy from your codebase |
|---|---|
| `.github/skills/sas-code-generator/templates/data_prep_template.py` | `make_loan_level_panel()` in `data_prep_lss.py` |
| `.github/skills/sas-code-generator/templates/panel_template.py` | `build_*_panel()` from `d120_panel.py` or `severity_panel.py` |
| `.github/skills/sas-code-generator/templates/scoring_template.py` | `score_data_linear()` from `severity_scoring.py` or `d120_scoring.py` |
| `.github/skills/sas-code-generator/templates/composed_module.py` | `ComposedModule` from `util.py` or `core.py` |

After setup, the code generator has both the **required style reference** and the **production implementation templates**.

---

## GitHub Copilot Agent Mode — Important Setup

Open this repository as the VS Code workspace and start a **new Agent Mode chat** before running a slash command.

The project prompt files intentionally have **no `tools:` frontmatter** for Stage 1, code review, and tests. This is required because a restrictive `tools:` list can prevent Copilot from using its normal workspace file, file-write, and terminal capabilities.

| Do | Do not do |
|---|---|
| Use GitHub Copilot **Agent Mode**. | Do not use legacy `@workspace` syntax. |
| Let the agent read files already in the open repository. | Do not attach or paste SAS/log/CSV files that are already under `data/`. |
| Approve expected read/write/terminal operations through VS Code when prompted. | Do not approve unexpected deletion, overwrite, or modification of source SAS files. |
| Start a new chat after changing a `.prompt.md` or `SKILL.md` file. | Do not add a restrictive `tools:` line unless your VS Code environment has verified tool names. |

### Expected Stage 1 Behavior

Running `/run-stage1` should behave as follows:

```text
Read .sas and .log files in the open repository
        ↓
Create stage1_extraction/output/ if it does not exist
        ↓
Write execution_trace.json directly
        ↓
Return: “Stage 1 complete. Next: /run-stage2”
```

Stage 1 must **not** ask you to run a Python extraction script or manually create the output folder.

---

## Put Your Files in These Folders

```text
data/
  sas_scripts/       # SAS source files: .sas
  sas_logs/          # SAS execution logs: .log or .lst
  input_csv/         # Input CSV files used for generated-code testing
  tie_out/           # Optional SAS expected-output CSV files for tie-out tests
```

The agent reads these files directly from the open repository. If the files are outside the repository, open the correct parent folder in VS Code or provide the repository-relative location when asked.

---

## The Migration Workflow

Run these commands in GitHub Copilot Agent Mode. The output and next decision are shown for every stage.

| Order | Command | Purpose | Key artifact | Next decision |
|---:|---|---|---|---|
| 1 | `/run-stage1` | Extract SAS structure, logs, lineage inputs, and risk signals. | `stage1_extraction/output/execution_trace.json` | Run Stage 2. |
| 2 | `/run-stage2` | Map SAS blocks to production module types and complexity. | `policy/policy_registry.yaml` | HIGH → Stage 3; otherwise → Stage 4. |
| 3 | `/run-stage3` | Apply 5-run Self-Consistency to HIGH-complexity blocks. | Classification/tally JSON | ACCEPT → Stage 4; ESCALATE → MCTS. |
| 3a | `/run-mcts` | Resolve an escalated ambiguous pattern. | Final implementation method | Continue to Stage 4 or validation as directed. |
| 4 | `/run-stage4` | Generate code that follows the 10 Golden Rules and production templates. | Generated Python/NumPy module | Run code review. |
| 4b | `/run-review` | Review against the 10 Golden Rules; create a Markdown/Mermaid audit. | `docs/reviews/review_<module>.md` | APPROVED → testing; NEEDS REVISION → Stage 4. |
| 4c-A | `/run-csv-tieout-tests <module_name>` | Preferred testing path when `data/input_csv/` is populated. Generates CSV-driven pytest cases and optional SAS tie-out comparison. | Tests, manifests, and test/tie-out Markdown report | PASS → Stage 5; failure → Stage 4. |
| 4c-B | `/run-tests` | Synthetic-data pytest path if CSV input data is unavailable. | `tests/test_<module>.py` and pytest result | PASS → Stage 5; failure → Stage 4. |
| 5 | `/run-repair` | Diff generated output against SAS ground truth and generate minimal patches. | Diff report and patch | Loop until divergence is resolved. |

### Routing Diagram

```mermaid
flowchart TD
    A[/run-stage1\nExecution trace/] --> B[/run-stage2\nPattern-to-module map/]
    B --> C{Any HIGH\ncomplexity?}
    C -->|No| E[/run-stage4\nCode generation/]
    C -->|Yes| D[/run-stage3\nSelf-Consistency/]
    D -->|ACCEPT| E
    D -->|ESCALATE| M[/run-mcts/]
    M --> E
    E --> R[/run-review\nMarkdown + Mermaid audit/]
    R -->|NEEDS REVISION\nmax 2 retries| E
    R -->|APPROVED| T{Input CSVs\navailable?}
    T -->|Yes| CT[/run-csv-tieout-tests/]
    T -->|No| ST[/run-tests/]
    CT -->|Failure / Tie-out failure\nmax 3 retries| E
    ST -->|Test failure\nmax 3 retries| E
    CT -->|ALL PASS + tie-out PASS| V[/run-repair\nSAS diff validation/]
    ST -->|ALL PASS| V
    V --> Z[Human review and approval]
```

---

## The 10 Golden Rules

Every generated module and review report must use these production constraints.

| Rule | Required behavior |
|---:|---|
| 1 | Preserve SAS feature-engineering variable names. |
| 2 | Preserve SAS business formulas and calculation order. |
| 3 | Load model coefficients from approved YAML/CSV/config sources; never hardcode them. |
| 4 | Replace SAS execution loops with the approved NumPy/Python inference pattern, not generic Spark DataFrames. |
| 5 | Map SAS `BY`-group processing to loan-level dictionary flow and state handling. |
| 6 | Do not persist intermediate datasets; pass data in memory between composed modules. |
| 7 | Write output once at the top-level orchestrator; do not write module-level intermediate output. |
| 8 | Map SAS macro orchestration to `ComposedModule` chaining. |
| 9 | Preserve SAS variable names as Python dictionary keys where applicable. |
| 10 | Preserve required SAS output fields and output schema. |

---

## CSV-Driven Pytest and SAS Tie-Out Testing

The preferred test path is `/run-csv-tieout-tests <module_name>` when input CSVs are available.

### 1. Place CSV Files

```text
data/input_csv/     # Inputs used by the generated module
data/tie_out/       # Corresponding SAS expected-output CSV files
```

### 2. Configure the Test Mapping

Edit this file before a strict row-level tie-out:

```text
tests/test_data_config.yaml
```

At minimum, configure the key that exists in both the input and expected-output CSVs, the file pair for the module, and the output fields to compare.

```yaml
primary_key:
  - "trace_id"

module_data_sets:
  your_module_name:
    input_csv: "your_input.csv"
    sas_expected_csv: "your_sas_expected_output.csv"
    comparison_columns:
      - "defaultprob"
      - "postMIDefCostRatio"
    absolute_tolerance: 0.00000001
    relative_tolerance: 0.000001
```

List all prohibited fields in `sensitive_columns`. Those fields must never appear in generated fixtures, manifests, reports, or chat output.

### 3. Run the Command

```text
/run-csv-tieout-tests your_module_name
```

The agent performs the following actions locally:

1. Profiles input CSV metadata with bounded/chunked reads; it does not load raw portfolio data into the conversation.
2. Creates deterministic representative scenarios and module-specific boundary cases.
3. Generates pytest coverage for schema, normal path, boundaries, and business invariants.
4. When configured, compares generated Python/NumPy output to SAS expected output using the primary key, selected fields, and configured tolerance.
5. Runs pytest.
6. Writes a Markdown/Mermaid report.

### CSV Test Artifacts

```text
tests/
  test_data_config.yaml
  manifests/
    input_data_manifest_<module>.yaml
    selected_scenarios_<module>.yaml
  fixtures/
    # small approved/sanitized fixtures only
  test_<module>.py

docs/reviews/
  test_data_profile_<module>.md
```

The test report includes a data-profile summary, selection rules, pytest result, tie-out status, field-level variance table when needed, and Mermaid coverage/tie-out diagrams.

### Tie-Out Statuses

| Status | Meaning | Required action |
|---|---|---|
| `PASS` | All configured SAS/Python comparison fields matched within tolerance. | Proceed to `/run-repair` for broader SAS validation. |
| `TIE-OUT FAIL` | At least one configured field differed from SAS output. | Send the field-level variance report to `/run-stage4`, then repeat review and tests. |
| `TIE-OUT BLOCKED` | Input CSV exists, but a key, expected-output mapping, comparison field, or tolerance is missing. | Update only the missing entry in `tests/test_data_config.yaml`, then rerun. |
| `NOT CONFIGURED` | No SAS expected-output CSV is configured. | Synthetic/CSV-driven pytest can continue, but no SAS tie-out claim may be made. |

---

## Review and Test Self-Healing Limits

| Gate | Maximum automatic retries | Failure feedback sent to code generation |
|---|---:|---|
| `/run-review` | 2 | Rule violation, line number, and suggested fix. |
| `/run-tests` | 3 | Failing test, traceback summary, and suspected cause. |
| `/run-csv-tieout-tests` | 3 | Failing test or field-level SAS variance summary. |
| `/run-repair` | Continue until the configured validation outcome is met. | Diff evidence and minimal patch request. |

After the retry limit, stop automatic changes and request human review.

---

## Project Structure

```text
.github/
  copilot-instructions.md
  prompts/
    run-stage1.prompt.md
    run-stage2.prompt.md
    run-stage3.prompt.md
    run-stage4.prompt.md
    run-review.prompt.md
    run-tests.prompt.md
    run-csv-tieout-tests.prompt.md
    run-mcts.prompt.md
    run-repair.prompt.md
  skills/
    sas-trace-extractor/
    sas-pattern-to-module-mapper/
    sas-self-consistency/
    sas-code-generator/
      templates/
      references/
    sas-code-reviewer/
    sas-test-harness/
    sas-csv-tieout-test-harness/
    sas-mcts-fallback/
    sas-validation-repair/

data/
  sas_scripts/
  sas_logs/
  input_csv/
  tie_out/

docs/reviews/
policy/policy_registry.yaml
stage1_extraction/output/execution_trace.json
stage5_validation/
tests/
  test_data_config.yaml
  manifests/
  fixtures/
```

---

## Quick Start

After the one-time production-pattern setup, place your SAS files and optional CSV files under `data/`, start a new Agent Mode chat, and run:

```text
/run-stage1
```

Follow the **Next step** returned by each agent command. When input and SAS expected-output CSVs are available, use:

```text
/run-csv-tieout-tests <module_name>
```

For the exact v15-to-v16 file differences, see [CHANGELOG_v16.md](CHANGELOG_v16.md).
