---
name: sas-csv-tieout-test-harness
description: "Stage 4c. Use after generated migration code has passed code review. Read local CSV inputs from data/input_csv and optional SAS expected-output CSVs from data/tie_out, generate deterministic pytest coverage, run tests, and create a Markdown/Mermaid test and tie-out report."
argument-hint: "[module name] [optional input CSV name] [optional SAS expected-output CSV name]"
user-invocable: true
disable-model-invocation: false
---

# CSV-Driven Test Harness and SAS Tie-Out Agent — Stage 4c

## Purpose

Create and run a deterministic pytest suite for a generated migration module by using the CSV files already available in the open repository.

The two data sources have distinct roles:

| Data location | Role | Required? |
|---|---|---:|
| `data/input_csv/` | Real input schema, representative local scenarios, and business-relevant boundary discovery | Yes |
| `data/tie_out/` | SAS-produced expected outputs used for row-level or key-level comparison | Optional but strongly recommended |

> **The goal is not to copy production data into tests.** The goal is to use locally available CSVs to learn the real schema, select a controlled set of deterministic scenarios, create safe fixtures, and verify that generated Python/NumPy results match SAS expected outputs when tie-out data is available.

---

## Non-Negotiable Agent Rules

1. Use modern GitHub Copilot Agent Mode workspace tools. **Do not use `@workspace` syntax.**
2. Do not ask the user to attach CSVs if they are present in the open repository under `data/input_csv/` or `data/tie_out/`.
3. Do not print raw loan/customer records, sensitive identifiers, or full CSV contents into chat, Markdown reports, prompts, or source control.
4. Do not create a manual script for the user to execute. Create project test artifacts directly and run pytest through approved Agent Mode tools.
5. Read large CSVs efficiently. Inspect headers and profile data using a bounded sample or chunked local reads; do not load a large portfolio into the model context.
6. Use deterministic selection rules. Do not select test rows randomly.
7. Do not overwrite source CSVs, SAS output files, SAS programs, or production code.
8. Never silently declare a tie-out successful if the input/expected-output relationship, primary key, output columns, or tolerance is unknown. Report the blocker and request the minimal configuration needed.

---

## Required Repository Layout

```text
data/
  input_csv/                       # Input CSV files used by the generated Python module
  tie_out/                         # Optional SAS expected-output CSV files

tests/
  test_data_config.yaml            # Configuration described below
  manifests/                       # Generated metadata only
  fixtures/                        # Approved, small, sanitized fixtures only
  test_<module_name>.py            # Generated pytest module

docs/reviews/
  test_data_profile_<module>.md    # Generated Markdown + Mermaid report
```

Create any missing `tests/`, `tests/manifests/`, `tests/fixtures/`, or `docs/reviews/` directories directly.

---

## Required Configuration

Read `tests/test_data_config.yaml` first. If it does not exist, create it from the template below and ask the user to fill only the fields marked `REQUIRED` before attempting a strict SAS tie-out.

```yaml
# tests/test_data_config.yaml
input_csv_root: "data/input_csv"
tie_out_csv_root: "data/tie_out"

# REQUIRED for a strict row-level SAS tie-out.
primary_key:
  - "trace_id"

# Map the generated module to its input and SAS expected-output CSVs.
# Add one entry for each module under test.
module_data_sets:
  example_module:
    input_csv: "loan_panel_input.csv"
    sas_expected_csv: "loan_panel_sas_output.csv"
    # Fields to compare. Use the exact SAS/Python output column names.
    comparison_columns:
      - "defaultprob"
      - "preMIDefCostRatio"
      - "postMIDefCostRatio"
    # Numeric comparisons use abs(actual - expected) <= absolute_tolerance
    # and relative tolerance where appropriate.
    absolute_tolerance: 0.00000001
    relative_tolerance: 0.000001

# Never expose these fields in manifests, reports, generated fixtures, or chat.
sensitive_columns:
  - "loan_id"
  - "borrower_name"
  - "ssn"
  - "address"

# Maximum number of approved records written to a fixture.
max_fixture_rows: 20
```

### Pairing Rules

Use the explicit `module_data_sets` mapping whenever available. Do not infer a pair based solely on similarly named files when an explicit mapping is absent.

If strict tie-out mapping is not configured, still run schema, unit, boundary, and property tests. Mark the report as:

```text
Tie-out status: BLOCKED — primary key or expected output mapping is not configured.
```

---

## Step-by-Step Workflow

### Step 1 — Discover Data Files

Inspect these workspace paths:

```text
data/input_csv/**/*.csv
data/tie_out/**/*.csv
tests/test_data_config.yaml
```

Report only the relative file paths and counts. Do not display contents.

If `data/input_csv/` contains no CSV files, ask the user for the repository-relative path. If it contains CSV files, continue without asking for attachments.

### Step 2 — Build a Safe Input Data Manifest

For each selected input CSV, create:

```text
tests/manifests/input_data_manifest_<module>.yaml
```

The manifest must contain only metadata:

```yaml
source_file: "data/input_csv/loan_panel_input.csv"
row_count_estimate: 35000000
columns:
  - name: "amort_oltv"
    inferred_type: "float"
    null_count_estimate: 12
    min: 0.12
    p50: 0.74
    p99: 1.31
  - name: "age"
    inferred_type: "integer"
    null_count_estimate: 0
    min: 0
    p50: 47
primary_key_present: true
sensitive_columns_excluded: ["loan_id"]
```

Use chunked reads or a bounded sample for large files. The manifest must never contain raw row values or actual sensitive identifiers.

### Step 3 — Create Deterministic Scenario Definitions

Create:

```text
tests/manifests/selected_scenarios_<module>.yaml
```

Select scenarios by explicit business rule, not randomness. The minimum scenarios are:

| Scenario | Selection or construction rule | Purpose |
|---|---|---|
| `normal_valid_case` | First non-null valid record satisfying standard business range | Confirms normal execution path |
| `first_month_reset` | Real record transformed to `age = 0` | Checks RETAIN/BY-group reset logic |
| `mi_cancellation_at_boundary` | Real record transformed to `amort_oltv = 0.78` | Checks MI cancellation boundary when relevant |
| `below_mi_boundary` | Real record transformed to `amort_oltv = 0.7799` | Checks behavior immediately below boundary |
| `above_mi_boundary` | Real record transformed to `amort_oltv = 0.7801` | Checks behavior immediately above boundary |
| `zero_upb_guard` | Real record transformed to `oupb = 0.0` | Checks divide-by-zero safety where relevant |
| `missing_lookup_key` | Real record with a required lookup key removed or set to an absent value | Checks missing CPI/config lookup handling |

Only include scenarios that apply to the module. For every excluded standard scenario, state the reason in the report.

Use a hashed primary-key value in manifests:

```yaml
scenario: "normal_valid_case"
selection_rule: "first record with 0.60 < amort_oltv < 0.78 and non-null age"
source_key_hash: "sha256:<hash>"
fixture_type: "approved_local_row"
```

### Step 4 — Create Approved Test Fixtures

Generate small local fixture files under:

```text
tests/fixtures/
```

Fixtures must have no more than `max_fixture_rows` records and must exclude all `sensitive_columns` from the configuration. Preserve the SAS business-variable names required to execute the module.

Use real non-sensitive values only when your organization permits test fixtures in the repository. If local data cannot be written to source control, create fixtures as local, ignored test artifacts and state that in the report. If organizational policy prohibits storing any real values, use the CSV solely to derive schema and ranges, then create fully synthetic values that satisfy those ranges.

### Step 5 — Generate pytest Coverage

Create or update:

```text
tests/test_<module_name>.py
```

The pytest suite must contain the following layers.

| Test layer | Requirement |
|---|---|
| Schema contract | Verify required input columns exist and generated output includes the expected output fields |
| Normal-path unit test | Execute the module using `normal_valid_case` |
| Boundary tests | Execute all relevant scenarios from `selected_scenarios_<module>.yaml` |
| Property/invariant tests | Validate non-negative probabilities, stable schema, expected null behavior, and module-specific business invariants |
| SAS tie-out test | Required when valid input/output mapping and primary key are configured |

Use an explicit tolerance for floating-point comparisons. Never use exact equality for a floating-point model output unless the field is declared categorical, string, integer, or boolean.

### Step 6 — Generate SAS Tie-Out Tests

When `sas_expected_csv` and `primary_key` are configured, create tests that:

1. Read only the selected approved trace records from the input CSV.
2. Locate expected SAS output records using the configured primary key.
3. Run the generated Python/NumPy module for each selected input record.
4. Compare only configured `comparison_columns`.
5. Use `pytest.approx` or equivalent tolerance logic for numeric fields.
6. Produce a clear failure message containing the scenario name, field name, expected value, actual value, absolute difference, and tolerance — but never include sensitive identifiers.

Example pattern:

```python
@pytest.mark.parametrize("scenario_name", APPROVED_SCENARIOS)
def test_generated_python_matches_sas_expected_output(
    scenario_name,
    input_record_by_scenario,
    sas_expected_record_by_scenario,
):
    actual = module_under_test(input_record_by_scenario[scenario_name])
    expected = sas_expected_record_by_scenario[scenario_name]

    for column in COMPARISON_COLUMNS:
        assert actual[column] == pytest.approx(
            expected[column],
            abs=ABSOLUTE_TOLERANCE,
            rel=RELATIVE_TOLERANCE,
        ), f"Tie-out mismatch: scenario={scenario_name}, field={column}"
```

### Step 7 — Run Tests

Use Agent Mode terminal tools to run:

```bash
pytest tests/ -v --tb=short
```

Do not ask the user to execute the command manually. If the project uses a virtual environment or dependency manager, detect and use its documented test command from `AGENTS.md`, `README.md`, or project configuration.

### Step 8 — Write the Markdown and Mermaid Report

Write:

```text
docs/reviews/test_data_profile_<module>.md
```

The report must contain:

1. Data-source inventory (paths and counts only).
2. Input schema and profiling summary, without raw data.
3. Test scenarios and their deterministic selection rules.
4. Test results: pass/fail count and failing test names.
5. Tie-out status: `PASS`, `FAIL`, `BLOCKED`, or `NOT CONFIGURED`.
6. A tie-out variance table when differences occur, without sensitive IDs.
7. The two Mermaid diagrams below, generated from actual discovered inputs, tests, and comparison fields.

**Required coverage diagram:**

```mermaid
flowchart TD
    A[input CSV] --> B[Schema Profile]
    B --> C[Approved Deterministic Scenarios]
    C --> D[Normal Path Test]
    C --> E[Boundary Tests]
    C --> F[Property Tests]
    D --> G[pytest]
    E --> G
    F --> G
```

**Required tie-out diagram when SAS output is available:**

```mermaid
flowchart LR
    A[Input CSV: selected scenarios] --> B[Generated Python/NumPy module]
    A --> C[SAS expected-output CSV]
    B --> D[Field-level comparison]
    C --> D
    D --> E{Within configured tolerance?}
    E -->|Yes| F[Tie-out PASS]
    E -->|No| G[Variance table and repair request]
```

---

## Decision Rules and Next Step

| Condition | Status | Required next action |
|---|---|---|
| All unit, boundary, property, and tie-out tests pass | `ALL PASS` | Proceed to `/run-repair` for broader SAS diff validation |
| Unit/boundary/property test fails | `NEEDS REVISION` | Send failing test, traceback, and suspected cause to `/run-stage4` |
| Tie-out differs | `TIE-OUT FAIL` | Send field-level variance summary to `/run-stage4`; then rerun review and tests |
| Input CSV exists but SAS expected CSV/key mapping missing | `TIE-OUT BLOCKED` | Complete non-tie-out tests; request minimal configuration update |
| CSV files unavailable | `DATA BLOCKED` | Ask only for the repository-relative data location |

Limit automatic test-driven regeneration to **three retries**. After three failed retries, stop and request human review with the latest test output and variance report.

---

## Required Completion Response

Use this exact structure after every run:

```markdown
## CSV-Driven Test Harness Complete

**Module:** `[module_name]`
**Input CSV:** `[relative path]`
**SAS tie-out CSV:** `[relative path, or Not configured]`

| Result | Value |
|---|---:|
| Input columns profiled | [count] |
| Deterministic scenarios generated | [count] |
| pytest tests passed | [count] |
| pytest tests failed | [count] |
| Tie-out fields compared | [count] |
| Tie-out status | [PASS / FAIL / BLOCKED / NOT CONFIGURED] |

**Created:**
- `tests/manifests/input_data_manifest_[module].yaml`
- `tests/manifests/selected_scenarios_[module].yaml`
- `tests/test_[module].py`
- `docs/reviews/test_data_profile_[module].md`

**Next step:** [exact command or corrective action].
```

---

## Next Step

- If `ALL PASS` and tie-out status is `PASS`, run `/run-repair` for the full SAS validation/diff process.
- If any result is `NEEDS REVISION` or `TIE-OUT FAIL`, return the exact failure evidence to `/run-stage4` before proceeding.
- If tie-out is `BLOCKED`, complete `tests/test_data_config.yaml` and rerun this skill.
