---
name: sas-trace-extractor
description: "Stage 1 of the SAS migration workflow. Use when asked to extract a SAS execution trace, scan SAS scripts and SAS logs, create execution_trace.json, or begin a SAS-to-NumPy migration. Read files already available in the open VS Code workspace, extract structural metadata, and write the JSON artifact directly."
argument-hint: "[optional path to SAS source folder or a specific SAS program]"
user-invocable: true
disable-model-invocation: false
---

# SAS Trace Extractor — Stage 1

## Purpose

Create a single machine-readable execution-trace artifact that gives later migration stages a reliable view of the SAS programs, data dependencies, macros, execution evidence, and risk signals in the **open VS Code workspace**.

> **Stage 1 is an agent task, not a manual scripting task.** Use Agent Mode workspace tools to inspect files, create a missing output directory, and write the JSON result directly.

The required artifact is:

```text
stage1_extraction/output/execution_trace.json
```

---

## Non-Negotiable Workspace Rules

1. **Do not use `@workspace` syntax.** It is legacy syntax and is not required in newer GitHub Copilot Agent Mode.
2. **Do not ask the user to attach, paste, select, or manually provide SAS files** when they are already located in the open repository.
3. **Do not create, propose, or ask the user to run a deterministic Python extraction script.** Read the workspace and write the JSON artifact directly with Agent Mode file tools.
4. If `stage1_extraction/output/` does not exist, **create it yourself**.
5. Ask the user for a path only when no relevant `.sas`, `.log`, or `.sas7bdat` files can be found in the workspace, or when required files are outside the opened repository or inaccessible.
6. Do not modify SAS source programs, production Python/NumPy modules, or source log files during this stage.
7. Extract **metadata only**. Do not copy customer/loan-level records, raw data values, or sensitive identifiers into the trace.

---

## Inputs: Where to Look

First inspect the repository root and locate the SAS source and log files. Use this priority order:

| Priority | Location to scan | File patterns |
|---:|---|---|
| 1 | `data/sas_scripts/` | `**/*.sas` |
| 2 | `data/sas_logs/` | `**/*.log`, `**/*.lst` |
| 3 | User-provided path supplied with the slash command | `**/*.sas`, `**/*.log`, `**/*.lst` |
| 4 | Remaining open workspace directories | `**/*.sas`, `**/*.log`, `**/*.lst` |

If the user invokes this skill with a specific path, prioritize that location. Otherwise, use the standard `data/` locations first.

---

## Required Agent Workflow

### Step 1 — Discover Relevant Files

Use workspace search/file tools to identify all accessible SAS programs and log files. Build a short internal inventory containing each relative path. Do not stop after inspecting one SAS program: scan all discovered `.sas` and `.log` files in the selected scope.

If no SAS programs are found, stop and ask one concise question:

> “I could not find any `.sas` files in the open workspace. Please provide the repository-relative folder containing the SAS source, or open the repository that contains it.”

### Step 2 — Read SAS Programs

For each `.sas` program, identify the following structural information.

| Category | Extract |
|---|---|
| Program identity | Relative path and program name |
| Macros | `%macro` definitions, macro parameters, `%mend`, `%include`, macro invocations |
| DATA steps | Output dataset, input datasets, `SET`, `MERGE`, `UPDATE`, `MODIFY`, `BY` keys, `RETAIN` variables, `KEEP`, `DROP`, and `WHERE` clauses |
| PROC SQL | Created table, source tables, joins, join types when explicit, `GROUP BY`, and calculated output columns when identifiable |
| Other procedures | Procedure name and significant inputs/outputs, including `PROC SORT`, `PROC SUMMARY`, `PROC MEANS`, `PROC TRANSPOSE`, `PROC APPEND`, `PROC EXPORT`, and `PROC DATASETS` |
| External dependencies | `%include` files, `LIBNAME` assignments, `FILENAME` references, formats, and model/config files when visible |
| Risk signals | `RETAIN`, `FIRST.`/`LAST.`, `LAG`, `DIF`, `CALL SYMPUT`, `SYMGET`, arrays, loops, `MORT`, `INTCK`, `INTNX`, `PROC SQL` remerges, macros, and pass-through SQL |

For each data transformation, preserve dataset and variable names exactly as written in SAS whenever they can be determined.

### Step 3 — Read SAS Logs

For each `.log` or `.lst` file, extract only execution metadata:

- Row/observation counts by dataset where present.
- Elapsed runtime or CPU time where present.
- Warnings, errors, and notable notes.
- Evidence that a dataset was created with zero observations, when present.
- Sort/merge warnings, uninitialized-variable warnings, numeric-conversion warnings, or missing-value warnings.

Do not treat standard informational `NOTE:` lines as errors. Record them only if they indicate a migration-relevant behavior, such as zero observations, implicit conversion, truncation, or merge anomalies.

### Step 4 — Create the Output Directory

Ensure this directory exists:

```text
stage1_extraction/output/
```

If it is missing, create it directly. Do not ask the user to create it.

### Step 5 — Write `execution_trace.json` Directly

Create or overwrite the artifact at:

```text
stage1_extraction/output/execution_trace.json
```

The file must be valid JSON, use two-space indentation, and conform to the required schema below. Use empty arrays (`[]`) or empty objects (`{}`) when information is unavailable; never invent values.

---

## Required JSON Schema

```json
{
  "trace_version": "1.0",
  "generated_by": "GitHub Copilot Agent Mode - sas-trace-extractor",
  "source_scope": {
    "sas_source_roots": ["data/sas_scripts"],
    "sas_log_roots": ["data/sas_logs"],
    "files_scanned": {
      "sas_programs": ["data/sas_scripts/example.sas"],
      "logs": ["data/sas_logs/example.log"]
    }
  },
  "scripts": {
    "data/sas_scripts/example.sas": {
      "macros_defined": [
        {
          "name": "BUILD_PANEL",
          "parameters": ["as_of_date"]
        }
      ],
      "macro_invocations": ["BUILD_PANEL"],
      "includes": ["common/macros.sas"],
      "libnames": ["RAW", "WORK"],
      "data_steps": [
        {
          "step_name": "panel_build",
          "output_dataset": "WORK.PANEL",
          "input_datasets": ["RAW.LOANS", "RAW.PAYMENTS"],
          "operations": ["SET", "MERGE"],
          "by_variables": ["loan_id", "as_of_date"],
          "retain_variables": ["balance"],
          "keep_variables": [],
          "drop_variables": [],
          "where_conditions": [],
          "risk_signals": ["RETAIN", "FIRST./LAST."]
        }
      ],
      "proc_sql": [
        {
          "output_dataset": "WORK.SCORED",
          "input_datasets": ["WORK.PANEL", "RAW.CPI"],
          "joins": [
            {
              "left_table": "WORK.PANEL",
              "right_table": "RAW.CPI",
              "join_type": "LEFT",
              "condition": "panel.month = cpi.month"
            }
          ],
          "group_by": [],
          "risk_signals": []
        }
      ],
      "procedures": [
        {
          "name": "SORT",
          "input_datasets": ["RAW.LOANS"],
          "output_dataset": "WORK.LOANS_SORTED"
        }
      ],
      "risk_signals": ["RETAIN", "MACRO", "PROC SQL JOIN"],
      "unresolved_references": []
    }
  },
  "logs": {
    "data/sas_logs/example.log": {
      "row_counts": {
        "WORK.PANEL": 35000000
      },
      "runtime_seconds": 45.2,
      "warnings": [],
      "errors": [],
      "migration_relevant_notes": [
        "WORK.PANEL was created with 0 observations"
      ]
    }
  },
  "cross_program_summary": {
    "datasets_produced": ["WORK.PANEL", "WORK.SCORED"],
    "datasets_consumed": ["RAW.LOANS", "RAW.PAYMENTS", "RAW.CPI"],
    "high_risk_patterns": [
      {
        "pattern": "RETAIN with BY-group reset",
        "source_file": "data/sas_scripts/example.sas",
        "location_hint": "DATA step panel_build"
      }
    ],
    "unresolved_dependencies": []
  }
}
```

---

## Extraction Quality Checks

Before finishing, verify all of the following:

| Check | Required result |
|---|---|
| File created | `stage1_extraction/output/execution_trace.json` exists in the workspace |
| Valid JSON | The artifact parses as JSON and has no comments or trailing commas |
| Complete inventory | All discovered SAS programs and logs in scope appear under `source_scope.files_scanned` |
| No invention | Unknown values are empty arrays/objects or omitted; no fabricated datasets, row counts, or runtimes |
| Exact names | SAS dataset and variable names retain their original spelling/case as found in source |
| Privacy | No raw loan/customer rows or sensitive record values are copied into the artifact |
| No code generation | No Python migration code or extraction script was created during Stage 1 |

---

## Required Completion Response

After successfully writing and validating the JSON file, respond with exactly this structure, replacing the bracketed values:

```markdown
## Stage 1 Complete

**Created:** `stage1_extraction/output/execution_trace.json`

| Item | Count |
|---|---:|
| SAS programs scanned | [count] |
| SAS logs scanned | [count] |
| DATA steps found | [count] |
| PROC SQL steps found | [count] |
| HIGH-risk signals found | [count] |

**Top migration risks:** [comma-separated list, or `None detected`].

**Next step:** Run `/run-stage2` to build the column dependency graph and map SAS blocks to the production module patterns.
```

If the artifact cannot be created because the repository is read-only, report the exact intended path and the permission limitation. Do not fall back to a script or ask the user to manually extract the trace.

---

## Next Step

After a successful Stage 1 run, the next command is:

```text
/run-stage2
```

Stage 2 reads `stage1_extraction/output/execution_trace.json` together with the SAS source already present in the workspace; the user should not need to reattach the same files.
