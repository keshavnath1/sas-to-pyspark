---
agent: 'agent'
name: 'run-csv-tieout-tests'
description: 'Generate and run CSV-driven pytest tests with optional SAS expected-output tie-out comparison'
argument-hint: '[module name] [optional input CSV] [optional SAS expected-output CSV]'
---

Execute `.github/skills/sas-csv-tieout-test-harness/SKILL.md`.

Use Agent Mode workspace tools to inspect and use files already available in the open repository:

```text
data/input_csv/
data/tie_out/
tests/test_data_config.yaml
```

Do not use `@workspace` syntax. Do not ask the user to attach, paste, or manually select CSV files that are already available in the open repository. Do not create a script for the user to run manually.

Perform the workflow end to end:

1. Read `tests/test_data_config.yaml`. If it does not exist, create it from the skill template and identify the minimal fields requiring user configuration.
2. Discover local input CSVs under `data/input_csv/` and optional SAS expected-output CSVs under `data/tie_out/`.
3. Profile only metadata using bounded/chunked local reads. Do not expose raw records, sensitive fields, or real identifiers in chat, reports, fixtures, or source control.
4. Create deterministic representative scenarios and boundary cases from the actual input schema and business ranges.
5. Generate safe pytest files and small approved fixtures under `tests/`.
6. When the input/expected-output mapping, primary key, comparison fields, and tolerances are configured, generate SAS tie-out tests that compare generated Python/NumPy results against SAS output by key and field.
7. Run the project test command. If no documented alternative exists, run:

   ```bash
   pytest tests/ -v --tb=short
   ```

8. Write `docs/reviews/test_data_profile_<module>.md`, including the CSV profile, scenarios, test results, tie-out status, a coverage Mermaid diagram, and a tie-out Mermaid diagram when SAS expected output is available.

Return the required completion summary from the skill with one final status:

- `ALL PASS` — all generated tests and the configured SAS tie-out passed; next: `/run-repair`.
- `NEEDS REVISION` — unit, boundary, or property test failed; return the failing test and traceback to `/run-stage4`.
- `TIE-OUT FAIL` — SAS comparison differs; return a field-level variance summary to `/run-stage4`.
- `TIE-OUT BLOCKED` — input CSV exists, but the key/mapping/expected-output configuration is incomplete; state the exact missing configuration only.
