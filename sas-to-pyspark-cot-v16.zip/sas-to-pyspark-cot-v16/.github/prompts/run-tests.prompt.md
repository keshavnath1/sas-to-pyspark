---
agent: 'agent'
description: 'Run Stage 4c: Generate pytest tests with synthetic data and run them in the workspace'
---

Execute `.github/skills/sas-test-harness/SKILL.md`.

Use Agent Mode workspace tools to:

1. Read `.github/skills/sas-test-harness/boundary_cases.yaml`.
2. Generate deterministic synthetic loan data that covers normal, boundary, and failure-safe cases.
3. Create `tests/` if it does not exist.
4. Write a pytest suite to `tests/test_<module_name>.py`.
5. Run:

   ```bash
   pytest tests/ -v --tb=short
   ```

6. Analyze the actual test results.

Return `ALL PASS` with the test count and next step `/run-repair`, or return `NEEDS REVISION` with the failing test name, traceback summary, suspected cause, and precise correction request for `/run-stage4`.

Do not ask the user to attach files that are already in the open repository. Do not generate a test-running script for the user to execute manually.
