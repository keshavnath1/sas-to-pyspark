---
agent: 'agent'
description: 'Run Stage 1: Extract execution trace from SAS files already present in the workspace'
---

Execute `.github/skills/sas-trace-extractor/SKILL.md`.

Use Agent Mode workspace tools to scan the open repository. Read available `.sas` files and `.log` files, create `stage1_extraction/output/` if it does not exist, and write `stage1_extraction/output/execution_trace.json` directly.

Do not use `@workspace` syntax. Do not ask the user to attach or paste files that already exist in the open repository. Do not generate a Python extraction script.

After validating the JSON artifact, return the Stage 1 completion summary and direct the user to `/run-stage2`.
