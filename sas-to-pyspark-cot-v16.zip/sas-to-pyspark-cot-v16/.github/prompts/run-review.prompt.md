---
agent: 'agent'
description: 'Run Stage 4b: Review generated code against the 10 Golden Rules and create a Mermaid markdown audit report'
---

Execute `.github/skills/sas-code-reviewer/SKILL.md`.

Use Agent Mode workspace tools to read the generated Python file, evaluate it against `.github/skills/sas-code-reviewer/review_checklist.md`, and write the audit report to `docs/reviews/review_<module_name>.md`.

The report MUST include:

1. A rule-by-rule violations table with rule number, line number, issue, and suggested fix.
2. A Mermaid flowchart of the module composition chain.
3. A Mermaid flowchart of variable lineage from SAS variables to Python dictionary keys.

Return `APPROVED` or `NEEDS REVISION`. If revision is needed, return the exact violations to `/run-stage4`.

Do not ask the user to attach code already present in the open repository.
